
public class PapperSail extends Sail{
	public PapperSail(){
		setCost(50);
		setSpeedMod(0);
	}
}
