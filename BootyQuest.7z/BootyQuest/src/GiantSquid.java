
public class GiantSquid extends Monster{
	//----Basic Stat's----
	public GiantSquid(){
		setHp(100);
		setAttack(4);
		setDeffence(1);
		setSpeed(3);
		setDrop(80);
	}
	
	//----Methods----
	@Override
	public int attack() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int defence() {
		// TODO Auto-generated method stub
		return 0;
	}

}
