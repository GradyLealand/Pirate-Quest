
public class Gally extends Ship {
	//----Methods----
	public Gally(){
		setHpMax(70);
		setHpMin(50);
		setAttack(6);
		setDeffence(3);
		setSpeed(5);
	}

	//----Methods----
	@Override
	public int attack() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int defend() {
		// TODO Auto-generated method stub
		return 0;
	}
}
