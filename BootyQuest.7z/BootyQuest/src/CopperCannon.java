
public class CopperCannon extends Cannon{
	public CopperCannon(){
		setCost(50);
		setAttackMod(1);
	}
}
