import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Game {

	private JFrame frame;
	private JPanel shipBuilder; 
	private JPanel launch; 
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Game window = new Game();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Game() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 667, 577);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new CardLayout(0, 0));
		
		launch = new JPanel();
		frame.getContentPane().add(launch, "name_1813242725092839");
		launch.setLayout(null);
		
		JButton btnPlayGame = new JButton("Play Game");
		btnPlayGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				shipBuilder.setVisible(true);
				launch.setVisible(false);
			}
		});
		btnPlayGame.setBounds(251, 434, 144, 62);
		launch.add(btnPlayGame);
		
		shipBuilder = new JPanel();
		frame.getContentPane().add(shipBuilder, "name_1813247910124035");
		
		JButton btnNewButton = new JButton("New button");
		shipBuilder.add(btnNewButton);
		
		JPanel main = new JPanel();
		frame.getContentPane().add(main, "name_1813249021696804");
		
		JPanel shop = new JPanel();
		frame.getContentPane().add(shop, "name_1813250047058988");
		
		JPanel monsterSelect = new JPanel();
		frame.getContentPane().add(monsterSelect, "name_1813250887040700");
		
		JPanel battle = new JPanel();
		frame.getContentPane().add(battle, "name_1813251886169531");
	}

}
