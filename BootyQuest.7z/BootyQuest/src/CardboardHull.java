
public class CardboardHull extends Hull{
	public CardboardHull(){
		setCost(0);
		setDefenceMod(0);
	}
}
