
public class IronCannon extends Cannon{
	public IronCannon(){
		setCost(300);
		setAttackMod(3);
	}
}
