
public class Kracken extends Monster{
	//----Basic Stat's----
	public Kracken(){
		setHp(200);
		setAttack(6);
		setDeffence(3);
		setSpeed(3);
		setDrop(150);
	}
	
	//----Methods----
	@Override
	public int attack() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int defence() {
		// TODO Auto-generated method stub
		return 0;
	}

}
