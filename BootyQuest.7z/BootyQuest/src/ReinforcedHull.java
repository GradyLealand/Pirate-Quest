
public class ReinforcedHull extends Hull {
	public ReinforcedHull(){
		setCost(400);
		setDefenceMod(4);
	}
}
