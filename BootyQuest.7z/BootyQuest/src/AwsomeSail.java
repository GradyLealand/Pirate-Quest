
public class AwsomeSail extends Sail{
	public AwsomeSail(){
		setCost(400);
		setSpeedMod(2);
	}
}
