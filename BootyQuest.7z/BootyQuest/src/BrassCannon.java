
public class BrassCannon extends Cannon{
	public BrassCannon(){
		setCost(150);
		setAttackMod(2);
	}
}
