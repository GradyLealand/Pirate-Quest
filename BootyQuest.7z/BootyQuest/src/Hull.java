
public abstract class Hull extends Item{
	private int defenceMod = 0;

	public int geDefenceMod() {
		return defenceMod;
	}

	public void setDefenceMod(int defenceMod) {
		this.defenceMod = defenceMod;
	}
}
