
public class CardboardCannon extends Cannon{
	public CardboardCannon(){
		setCost(0);
		setAttackMod(0);
	}

}
