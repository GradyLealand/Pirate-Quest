
public class Skiff extends Ship{
	//----Base Stat's----
	public Skiff(){
		setHpMax(50);
		setHpMin(30);
		setAttack(3);
		setDeffence(2);
		setSpeed(3);
	}
	
	//----Methods----
	@Override
	public int attack() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int defend() {
		// TODO Auto-generated method stub
		return 0;
	}
}
