
public abstract class Sail extends Item{
	private int speedMod = 0;

	public int getSpeedMod() {
		return speedMod;
	}

	public void setSpeedMod(int speedMod) {
		this.speedMod = speedMod;
	}
	
}
