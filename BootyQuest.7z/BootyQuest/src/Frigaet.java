
public class Frigaet extends Ship{
	//----Methods----
	public Frigaet(){
		setHpMax(100);
		setHpMin(70);
		setAttack(5);
		setDeffence(4);
		setSpeed(6);
	}
	
	//----Methods----
	@Override
	public int attack() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int defend() {
		// TODO Auto-generated method stub
		return 0;
	}
}
