
public abstract class Cannon extends Item {
	private int attackMod = 0;

	public int getAttackMod() {
		return attackMod;
	}

	public void setAttackMod(int attackMod) {
		this.attackMod = attackMod;
	}
}
