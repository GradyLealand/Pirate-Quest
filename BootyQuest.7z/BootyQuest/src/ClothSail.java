
public class ClothSail extends Sail{
	public ClothSail(){
		setCost(200);
		setSpeedMod(1);
	}
}
