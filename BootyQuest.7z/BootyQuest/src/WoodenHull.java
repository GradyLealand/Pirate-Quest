
public class WoodenHull extends Hull {
	public WoodenHull(){
		setCost(150);
		setDefenceMod(2);	
	}
	
}
