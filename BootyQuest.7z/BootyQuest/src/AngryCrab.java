
public class AngryCrab extends Monster{
	//----Basic Stat's----
	public AngryCrab(){
		setHp(20);
		setAttack(1);
		setDeffence(1);
		setSpeed(3);
		setDrop(20);
	}
	
	//----Methods----
	@Override
	public int attack() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int defence() {
		// TODO Auto-generated method stub
		return 0;
	}
}
