
public class GiantClam extends Monster{
	//----Basic Stat's----
	public GiantClam(){
		setHp(60);
		setAttack(2);
		setDeffence(3);
		setSpeed(4);
		setDrop(50);
	}
	
	//----Methods----
	@Override
	public int attack() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int defence() {
		// TODO Auto-generated method stub
		return 0;
	}

}
